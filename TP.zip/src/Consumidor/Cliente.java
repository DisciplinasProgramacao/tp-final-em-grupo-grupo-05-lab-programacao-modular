package Consumidor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Restaurante.ExcecaoLimiteAvaliacaoInvalida;
import Restaurante.Pedido;

public class Cliente implements Serializable {
    List<Pedido> pedidos;
    Fidelidade fidelidade;
    String nome;

    public String getNome() {
        return nome;
    }

    String cpf;

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) throws ExcecaoCPFInvalido {
        if(cpf.matches("^[0-9]{3}[\\.][0-9]{3}[\\.][0-9]{3}[\\-][0-9]{2}$")) {
            this.cpf = cpf;
        }
        else {
            throw new ExcecaoCPFInvalido();
        }
    }

    public Cliente(String nome, String cpf) throws ExcecaoCPFInvalido{
        fidelidade = Fidelidade.BRANCO;
        pedidos = new ArrayList<Pedido>();
        this.nome = nome;
        setCpf(cpf);
    }

    public Fidelidade getFidelidade() {
        return fidelidade;
    }

    public void setFidelidade(Fidelidade fidelidade) {
        this.fidelidade = fidelidade;
    }

    /**
     * Finaliza o pedido
     * @param pedido Pedido que está sendo realizado
     */
    public void realizarPedido(Pedido pedido) {
        verificarFidelidadeCliente();
        
        obterDescontoNoPedidoPorFidelidade(pedido);
        avaliarPedido(pedido);
        RelatorioPedido.getInstancia().solicitarExtratoPedidoEspecifico(this, pedido);

        pedidos.add(pedido);
    }

    /**
     * Realiza uma avaliação no pedido que está sendo concluído 
     * @param pedido Pedido que está sendo concluído
    */
    public void avaliarPedido(Pedido pedido) {
        try {
            Scanner sc = new Scanner(System.in);
            int avaliacao;

            do {
                System.out.print("Digite a nota da sua avaliação (Entre 1 e 5):");
                avaliacao = sc.nextInt();
            } while(avaliacao <= 0 && avaliacao > 5);

            pedido.setAvaliacao(avaliacao);
        } catch (ExcecaoLimiteAvaliacaoInvalida e) {
            System.err.println(e.getMessage());
        }
    }
    /**
     * Obtem a fidelidade do cliente e atribui o valor para a propriedade fidelidade
    */
    public void verificarFidelidadeCliente() {
        Fidelidade fidelidadeCliente = FidelidadeCliente.getInstancia().obterFidelidade(pedidos);
        if (!fidelidade.equals(fidelidadeCliente)) {
            setFidelidade(fidelidadeCliente);
        }
    } 
    
    /**
     * Obtem um desconto a partir do nível de fidelidade do cliente
     * @param pedido Pedido que o cliente está realizando
    */
    public void obterDescontoNoPedidoPorFidelidade(Pedido pedido) {
        double novoValorPedido = pedido.getValorTotalPedido() - getFidelidade().getDesconto();
        pedido.setValorComDesconto(novoValorPedido);
    }

    /**
     * Obtem a avaliação média dos pedidos que o cliente já avaliou
     * @return Média de avaliações
     */
    public double obterAvaliacaoMedia() {
        return pedidos.stream()
            .mapToDouble((pedido) -> pedido.getAvaliacao())
            .average()
            .orElse(0);
    }

    public List<Pedido> getPedidos() {
        return this.pedidos;
    }
}
