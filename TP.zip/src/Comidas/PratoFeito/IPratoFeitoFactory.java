package Comidas.PratoFeito;

public interface IPratoFeitoFactory {
    public PratoFeito criarPratoFeito();
}
