package Comidas.ProdutoComAdicionais.Pizza;

public interface IPizzaFactory {
    public Pizza criarPizza(boolean bordaRecheada);
}
