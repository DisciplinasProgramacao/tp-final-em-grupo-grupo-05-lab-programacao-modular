package Comidas.ProdutoComAdicionais.Sanduiche;

public interface ISanduicheFactory {
    public Sanduiche criarSanduiche(boolean paoArtesanal);
}
