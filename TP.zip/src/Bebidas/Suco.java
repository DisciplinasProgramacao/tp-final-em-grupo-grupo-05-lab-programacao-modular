package Bebidas;

public class Suco extends Bebida {
    Suco(String descricao, double preco) {
        super(descricao, preco);
    }
}
