package Bebidas;

public interface IBebidaFactory {
    public Bebida criarBebida(TipoBebida bebida);
}
