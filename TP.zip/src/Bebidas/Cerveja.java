package Bebidas;

public class Cerveja extends Bebida{
    Cerveja(String descricao, double preco) {
        super(descricao, preco);
    }
}
