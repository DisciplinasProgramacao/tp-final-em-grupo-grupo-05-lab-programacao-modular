package Bebidas;

public class Refrigerante extends Bebida {
    Refrigerante(String descricao, double preco) {
        super(descricao, preco);
    }
}
