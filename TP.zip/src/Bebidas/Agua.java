package Bebidas;

public class Agua extends Bebida{
    Agua(String descricao, double preco) {
        super(descricao, preco);
    }
}
